package com.vlados_app.myapplication2.cat_list.data

data class Cat(
    val id: String,
    val url: String?,
)