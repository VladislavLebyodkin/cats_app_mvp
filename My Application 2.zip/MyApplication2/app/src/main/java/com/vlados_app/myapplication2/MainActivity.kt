package com.vlados_app.myapplication2

import android.os.Bundle
import com.arellomobile.mvp.MvpAppCompatActivity
import com.vlados_app.myapplication2.cat_list.presentation.CatListFragment

class MainActivity : MvpAppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fragment = CatListFragment.newInstance()

        val fragmentManager = supportFragmentManager
        fragmentManager.beginTransaction()
            .add(R.id.fragment_container, fragment)
            .commit()

    }
}