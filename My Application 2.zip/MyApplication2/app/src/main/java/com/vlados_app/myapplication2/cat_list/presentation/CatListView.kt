package com.vlados_app.myapplication2.cat_list.presentation

import com.arellomobile.mvp.MvpView
import com.vlados_app.myapplication2.cat_list.data.Cat

interface CatListView : MvpView {
    fun loadCatList(items: List<Cat>)
    fun showLoading()
    fun hideLoading()
    fun showError(errorText: String)
}