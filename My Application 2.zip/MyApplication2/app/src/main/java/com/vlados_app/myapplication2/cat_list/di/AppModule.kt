//package com.vlados_app.myapplication2.cat_list.di
//
//import com.vlados_app.myapplication2.cat_list.data.CatService
//import com.vlados_app.myapplication2.cat_list.presentation.CatListFragment
//import dagger.Component
//import dagger.Module
//import dagger.Provides
//import javax.inject.Qualifier
//import javax.inject.Scope
//
//@AppScope
//@Component(modules = [AppModule::class])
//interface AppComponent {
//
//    fun inject(fragment: CatListFragment)
//
////    @Component.Builder
////    interface Builder {
////
////        @BindsInstance
////        fun application(application: Application): Builder
////
////        @BindsInstance
////        fun apiKey(@ApiKeyQualifier apiKey: String): Builder
////
////        fun build(): AppComponent
////    }
//}
//
//@Module
//class AppModule {
//    @Provides
//    fun provideCatService(@ApiKeyQualifier apiKey: String): CatService {
//        return CatService(apiKey)
//    }
//}
//
//@Scope
//annotation class AppScope
//
//@Qualifier
//annotation class ApiKeyQualifier