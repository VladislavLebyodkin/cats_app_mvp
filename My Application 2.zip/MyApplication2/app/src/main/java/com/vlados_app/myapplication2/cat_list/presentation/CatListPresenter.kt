package com.vlados_app.myapplication2.cat_list.presentation

import android.annotation.SuppressLint
import android.util.Log
import com.arellomobile.mvp.InjectViewState
import com.arellomobile.mvp.MvpPresenter
import com.vlados_app.myapplication2.cat_list.data.CatService
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

@InjectViewState
class CatListPresenter : MvpPresenter<CatListView>() {

    @SuppressLint("CheckResult")
    fun loadCatList() {
        val key = "live_5WVW2pzGrLJCL7i8IC91Ed7WJ6OsgXQ5RaUZb4KBF1spZI1bhPc3ZAyz8ljABQcV"
        val service = CatService(key)

        viewState.showLoading()
        service.loadCatList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .doFinally(viewState::hideLoading)
            .subscribe(
                {
                    Log.d("TAGDEBUG", "success: $it")
                }, {
                    Log.d("TAGDEBUG", "error: $it")
                }
            )
    }
}