package com.vlados_app.myapplication2.cat_list.presentation

//import com.vlados_app.myapplication2.cat_list.di.DaggerAppComponent
import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.arellomobile.mvp.MvpAppCompatFragment
import com.arellomobile.mvp.presenter.InjectPresenter
import com.vlados_app.myapplication2.R
import com.vlados_app.myapplication2.cat_list.data.Cat


class CatListFragment : MvpAppCompatFragment(), CatListView {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_cat_list, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = CatListFragment()
    }

    @InjectPresenter
    lateinit var presenter: CatListPresenter

    private val adapter = CatListAdapter(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        DaggerAppComponent.create().inject(this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recycler)
        recyclerView.adapter = adapter

        val tv = view.findViewById<TextView>(R.id.tv)
        tv.setOnClickListener {
            presenter.loadCatList()
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun loadCatList(items: List<Cat>) {
        adapter.items = items
        adapter.notifyDataSetChanged()
    }

    override fun showLoading() {
        Log.d("TAGDEBUG", "showLoading")
    }

    override fun hideLoading() {
        Log.d("TAGDEBUG", "hideLoading")
    }

    override fun showError(errorText: String) {
        Log.d("TAGDEBUG", "showError")
    }
}