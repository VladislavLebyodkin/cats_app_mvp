package com.vlados_app.myapplication2

import android.app.Application
//import com.vlados_app.myapplication2.cat_list.di.DaggerAppComponent

class CatApp : Application() {

    override fun onCreate() {
        super.onCreate()

//        DaggerAppComponent.builder()
//            .application(this)
//            .apiKey(BuildConfig.CATS_API_KEY)
//            .build()

    }
}